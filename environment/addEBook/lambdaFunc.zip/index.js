const uuid = require('uuid');
const AWS = require('aws-sdk')
const dynamoDB = new AWS.DynamoDB({ region: 'us-west-2', apiVersion: '2012-08-10' })

exports.handler = (event, context, cb) => {
const run = () => {
    var params = {
        Item: {
            "id": {
                N: uuid.v4()
            },
            "title": {
                S: "test3"
            },
            "author": {
                S: "author3"
            },
            "genre": {
                S: "mystery"
            },
            "year": {
                N: "1990"
            },
            "content": {
                S: "This is the contents of book three"
            }
        },
        ReturnConsumedCapacity: "TOTAL",
        TableName: "eBooks"
    };
    dynamoDB.putItem(params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else {
            console.log(data); // successful response
        }
    });
}
};